
import { Routes, Route, Navigate } from 'react-router-dom'
import Container from '@mui/material/Container'
import Navbar from './components/Navbar.jsx'
import Home from './routes/Home.jsx'
import Login from './routes/Login.jsx'
import PatientDashboard from './routes/PatientDashboard.jsx'
import Questionnaire from './routes/Questionnaire.jsx'
import ImageOrText from './routes/ImageOrText.jsx'
import Result from './routes/Result.jsx'
import DoctorDashboard from './routes/DoctorDashboard.jsx'
import AdminDashboard from './routes/AdminDashboard.jsx'
import { useApp } from './state/AppContext.jsx'

function RequireRole({ role, children }) {
  const { auth } = useApp()
  if (!auth.isAuthed || auth.role !== role) return <Navigate to="/login" />
  return children
}

export default function App() {
  return (
    <>
      <Navbar />
      <Container maxWidth="lg" sx={{ pb: 8 }}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/patient" element={<RequireRole role="patient"><PatientDashboard /></RequireRole>} />
          <Route path="/patient/questionnaire" element={<RequireRole role="patient"><Questionnaire /></RequireRole>} />
          <Route path="/patient/input" element={<RequireRole role="patient"><ImageOrText /></RequireRole>} />
          <Route path="/patient/result" element={<RequireRole role="patient"><Result /></RequireRole>} />
          <Route path="/doctor" element={<RequireRole role="doctor"><DoctorDashboard /></RequireRole>} />
          <Route path="/admin" element={<RequireRole role="admin"><AdminDashboard /></RequireRole>} />
        </Routes>
      </Container>
    </>
  )
}
