
import AppBar from '@mui/material/AppBar'
import Toolbar from '@mui/material/Toolbar'
import Typography from '@mui/material/Typography'
import Button from '@mui/material/Button'
import { Link as RouterLink, useNavigate } from 'react-router-dom'
import { useApp } from '../state/AppContext.jsx'

export default function Navbar() {
  const { auth, setAuth } = useApp()
  const nav = useNavigate()
  const logout = () => { setAuth({ isAuthed: false, role: null, name: '' }); nav('/') }

  return (
    <AppBar position="static" color="primary" sx={{ mb: 2 }}>
      <Toolbar>
        <Typography variant="h6" sx={{ flexGrow: 1 }}>EdgeCare Triage (Demo)</Typography>
        <Button color="inherit" component={RouterLink} to="/">Home</Button>
        <Button color="inherit" component={RouterLink} to="/login">Login</Button>
        {auth.isAuthed && auth.role === 'patient' && <Button color="inherit" component={RouterLink} to="/patient">Patient</Button>}
        {auth.isAuthed && auth.role === 'doctor' && <Button color="inherit" component={RouterLink} to="/doctor">Doctor</Button>}
        {auth.isAuthed && auth.role === 'admin' && <Button color="inherit" component={RouterLink} to="/admin">Admin</Button>}
        {auth.isAuthed && <Button color="inherit" onClick={logout}>Logout</Button>}
      </Toolbar>
    </AppBar>
  )
}
