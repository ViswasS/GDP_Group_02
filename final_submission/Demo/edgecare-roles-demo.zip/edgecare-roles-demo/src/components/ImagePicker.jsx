
import { useRef } from 'react'
import { Box, Button } from '@mui/material'
export default function ImagePicker({ onPick, label='Choose Photo' }) {
  const fileRef = useRef()
  const handle = (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => onPick(file, reader.result)
    reader.readAsDataURL(file)
  }
  return (
    <Box>
      <input type="file" accept="image/*" ref={fileRef} onChange={handle} hidden />
      <Button variant="contained" onClick={() => fileRef.current.click()}>{label}</Button>
    </Box>
  )
}
