
import { Paper, Typography, Chip, Box, LinearProgress } from '@mui/material'
export default function ResultCard({ result, loading }) {
  if (loading) return <LinearProgress sx={{ mt: 2 }} />
  if (!result) return null
  const color = result.severity === 'high' ? 'error' : result.severity === 'moderate' ? 'warning' : 'success'
  return (
    <Paper sx={{ p: 3 }}>
      <Typography variant="h5" sx={{ mb: 1 }}>{result.recommendation}</Typography>
      <Chip color={color} label={`Severity: ${result.severity}`} sx={{ mr:1 }} />
      <Chip label={`Confidence: ${(result.confidence*100).toFixed(0)}%`} />
      <Box sx={{ mt: 2, color: 'text.secondary' }}>{result.advice}</Box>
    </Paper>
  )
}
