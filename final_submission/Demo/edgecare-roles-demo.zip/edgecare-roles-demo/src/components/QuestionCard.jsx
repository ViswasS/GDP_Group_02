
import { Paper, Typography } from '@mui/material'
export default function QuestionCard({ title, children }) {
  return (
    <Paper elevation={1} sx={{ p: 2, mb: 2 }}>
      <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 1 }}>{title}</Typography>
      {children}
    </Paper>
  )
}
