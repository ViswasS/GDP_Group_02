
import { createContext, useContext, useState } from 'react'

const Ctx = createContext(null)
export const useApp = () => useContext(Ctx)

export default function AppProvider({ children }) {
  const [auth, setAuth] = useState({ isAuthed: false, role: null, name: '' })
  const [caseData, setCaseData] = useState({
    questionnaire: { itch: 0, pain: 0, durationDays: '', meds: '', recurrence: false, bodyPart: '' },
    textDesc: '',
    image: null,
    imagePreview: '',
    result: null
  })
  return <Ctx.Provider value={{ auth, setAuth, caseData, setCaseData }}>{children}</Ctx.Provider>
}
