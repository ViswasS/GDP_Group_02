
export function mockInfer({ itch, pain, durationDays, recurrence, textDesc='' }) {
  let score = itch + pain + Number(durationDays || 0);
  if (recurrence) score += 2;
  const t = textDesc.toLowerCase();
  if (/(bleeding|spreading rapidly|fever|severe|oozing)/.test(t)) score += 6;
  if (/(mild|slight|itchy only|improved)/.test(t)) score -= 2;
  const severity = score >= 12 ? 'high' : score >= 6 ? 'moderate' : 'low';
  const recommendation = severity === 'high' ? 'Seek care' : 'Monitor at home';
  const confidence = Math.min(0.95, Math.max(0.55, 0.55 + score / 20));
  const advice = severity === 'high'
    ? 'Consult a doctor promptly. Keep area clean; avoid new products.'
    : 'Keep area clean and dry, avoid scratching, consider OTC hydrocortisone.';
  return { severity, recommendation, confidence, advice };
}
