
import { Paper, Typography, Table, TableBody, TableCell, TableHead, TableRow, Chip } from '@mui/material'

const users = [
  { id:'U-1', name:'Demo Patient', role:'patient', status:'active' },
  { id:'U-2', name:'Dr. Smith', role:'doctor', status:'active' },
  { id:'U-3', name:'Admin One', role:'admin', status:'active' },
]

export default function AdminDashboard() {
  return (
    <Paper sx={{ p:2 }}>
      <Typography variant="h6" sx={{ mb:1 }}>Admin Portal — Users (Demo)</Typography>
      <Table size="small">
        <TableHead>
          <TableRow><TableCell>ID</TableCell><TableCell>Name</TableCell><TableCell>Role</TableCell><TableCell>Status</TableCell></TableRow>
        </TableHead>
        <TableBody>
          {users.map(u => (
            <TableRow key={u.id}>
              <TableCell>{u.id}</TableCell>
              <TableCell>{u.name}</TableCell>
              <TableCell>{u.role}</TableCell>
              <TableCell><Chip color="success" label={u.status} /></TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Paper>
  )
}
