
import { useApp } from '../state/AppContext.jsx'
import { useNavigate } from 'react-router-dom'
import { Box, Button, Paper, Typography, TextField } from '@mui/material'
import ImagePicker from '../components/ImagePicker.jsx'

export default function ImageOrText() {
  const { caseData, setCaseData } = useApp()
  const nav = useNavigate()
  const onPick = (file, dataUrl) => setCaseData({ ...caseData, image: file, imagePreview: dataUrl })

  return (
    <Box>
      <Paper sx={{ p:2, mb:2 }}>
        <Typography variant="subtitle1" sx={{ fontWeight:600, mb:1 }}>Upload a clear, well-lit photo</Typography>
        <ImagePicker onPick={onPick} />
      </Paper>

      {caseData.imagePreview && (
        <Paper sx={{ p:2, mb:2 }}>
          <img src={caseData.imagePreview} alt="preview" style={{ maxWidth:'100%', borderRadius:8 }} />
        </Paper>
      )}

      <Paper sx={{ p:2, mb:2 }}>
        <Typography variant="subtitle1" sx={{ fontWeight:600, mb:1 }}>Or briefly describe your rash</Typography>
        <TextField
          fullWidth multiline minRows={3}
          placeholder="e.g., red itchy patch spreading for 3 days, a bit painful, no fever"
          value={caseData.textDesc}
          onChange={e=>setCaseData({ ...caseData, textDesc: e.target.value })}
        />
      </Paper>

      <Box sx={{ display:'flex', gap:2 }}>
        <Button variant="outlined" onClick={()=>nav('/patient/questionnaire')}>Back</Button>
        <Button variant="contained" onClick={()=>nav('/patient/result')}>
          Get Triage Result
        </Button>
      </Box>
    </Box>
  )
}
