
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Paper, Typography, TextField, MenuItem, Box, Button } from '@mui/material'
import { useApp } from '../state/AppContext.jsx'

export default function Login() {
  const { setAuth } = useApp()
  const nav = useNavigate()
  const [role, setRole] = useState('patient')
  const [name, setName] = useState('Demo User')

  const submit = () => {
    setAuth({ isAuthed: true, role, name })
    if (role === 'patient') nav('/patient')
    if (role === 'doctor') nav('/doctor')
    if (role === 'admin') nav('/admin')
  }

  return (
    <Paper sx={{ p:3, mt:2 }}>
      <Typography variant="h5" sx={{ mb:2 }}>Login (Demo)</Typography>
      <Box sx={{ display:'grid', gap:2, maxWidth:420 }}>
        <TextField label="Name" value={name} onChange={e=>setName(e.target.value)} />
        <TextField label="Role" value={role} select onChange={e=>setRole(e.target.value)}>
          <MenuItem value="patient">Patient</MenuItem>
          <MenuItem value="doctor">Doctor</MenuItem>
          <MenuItem value="admin">Admin</MenuItem>
        </TextField>
        <Button variant="contained" onClick={submit}>Continue</Button>
      </Box>
    </Paper>
  )
}
