
import { Paper, Typography, Box, Button } from '@mui/material'
import { Link as RouterLink } from 'react-router-dom'

export default function PatientDashboard() {
  return (
    <Paper sx={{ p:3 }}>
      <Typography variant="h6" sx={{ mb:1 }}>Patient Portal</Typography>
      <Typography color="text.secondary" sx={{ mb:2 }}>
        Start a new triage by answering questions and adding a rash image or a short description.
      </Typography>
      <Box sx={{ display:'flex', gap:2, flexWrap:'wrap' }}>
        <Button variant="contained" component={RouterLink} to="/patient/questionnaire">Start Questionnaire</Button>
        <Button variant="outlined" component={RouterLink} to="/patient/input">Add Image / Text</Button>
      </Box>
    </Paper>
  )
}
