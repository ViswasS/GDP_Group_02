
import { Link as RouterLink } from 'react-router-dom'
import { Box, Button, Typography, Paper } from '@mui/material'

export default function Home() {
  return (
    <Paper elevation={2} sx={{ p: 4, mt: 2 }}>
      <Typography variant="h4" gutterBottom>EdgeCare Triage — Rashes Pre‑Screen (Demo)</Typography>
      <Typography color="text.secondary" sx={{ mb: 3 }}>
        Patients can upload a rash photo or describe symptoms and receive clear guidance. Doctors and Admins have separate portals.
      </Typography>
      <Box sx={{ display:'flex', gap:2, flexWrap:'wrap' }}>
        <Button variant="contained" size="large" component={RouterLink} to="/login">Login</Button>
      </Box>
    </Paper>
  )
}
